package utils

import com.solution.utils.CommonUtils
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.should.Matchers

class CommonUtilsTest extends AnyFunSuite with Matchers {

  // Create a local SparkSession for testing
  val spark: SparkSession = SparkSession.builder()
    .appName("SparkTests")
    .master("local[*]")
    .config("spark.ui.port", "4041")
    .config("spark.driver.bindAddress", "127.0.0.1")
    .getOrCreate()

  import spark.implicits._

  test("readCsv function should load data correctly") {
    val data = CommonUtils.readCsv(spark, "src/test/resources/sample.csv")
    assert(data.count() > 0)  // Check that the DataFrame is not empty
    assert(data.columns.contains("memberID"))  // Check for a specific column
  }

  test("writeJson should write DataFrame correctly and read it back") {
    val testData = Seq(
      ("1", "John Doe"),
      ("2", "Jane Smith")
    ).toDF("memberID", "fullName")

    // Path to write JSON to (use a temporary directory)
    val path = "target/test/output/member"

    // Use the utility to write
    CommonUtils.writeJson(testData, path, "memberID")

    // Read back the data to check
    val readData = spark.read.json(path)
    assert(readData.count() == 2)
    assert(readData.columns.contains("memberID"))
  }

  // Cleanup after tests
  def afterAll(): Unit = {
    spark.stop()  // Stop Spark session after all tests
  }
}
