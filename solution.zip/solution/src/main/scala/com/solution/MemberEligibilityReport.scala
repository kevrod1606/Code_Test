package com.solution

import com.solution.utils.CommonUtils
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

/**
 * The main application for the Member Eligibility Report.
 * This application processes member data to calculate and report on member months.
 */
object MemberEligibilityReport {
  def main(args: Array[String]): Unit = {
    /*ToDo:
      Instead of using args we could use more advanced libraries like typeSafe or a
       config file. I used Array[String] for simplicity and ideally would not prefer using it.
     */
    // Check for correct number of arguments
    if (args.length < 4) {
      System.err.println("Usage: MemberEligibilityReport <member_eligibility_path> <member_months_path> <output_path_member_months> <output_path_member_months_per_year>")
      System.exit(1)
    }

    // Initialize SparkSession using the utility method
    val spark = CommonUtils.createSparkSession("Member Eligibility Analysis")

    // Read input data using utility methods
    val memberEligibilityDF = CommonUtils.readCsv(spark, args(0))
    val memberMonthsDF = CommonUtils.readCsv(spark, args(1))

    val updatedMemberEligibilityDF = memberEligibilityDF.withColumn(
      "fullName",
      concat_ws(" ", col("first_name"), col("middle_name"), col("last_name"))
    )

    // Perform the join on member_id (assuming this is the correct key and exists in both DataFrames)
    val combinedDF = updatedMemberEligibilityDF.join(memberMonthsDF, "member_id")
      .withColumn("year", year(col("eligiblity_effective_date"))) // Extract year from eligiblity_effective_date
      .withColumn("month", month(col("eligiblity_effective_date")))
      .repartition(col("member_id"), col("year"))

    // Persisting for performance
    combinedDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    //Force action to initiate repartition
    combinedDF.rdd.countApprox(timeout = 800,confidence = 0.10)

    // Calculate the total number of member months and group by member ID and full name
    val totalMemberMonthsDF = combinedDF
      .groupBy("member_id", "fullName")
      .agg(countDistinct("eligibility_member_month").as("totalMemberMonths"))

    // Write the total member months data to JSON files, partitioned by 'memberID'
    CommonUtils.writeJson(totalMemberMonthsDF, args(2), Some("member_id"),false,0)

    // Calculate the total number of member months per member per year and group by member ID and year
    val memberMonthsPerMemberPerYearDF = combinedDF
      .groupBy("member_id", "year","month")
      .agg(count("eligibility_member_month").as("total_member_months"))  // Count distinct months per member per year



    // Write the data to JSON files, partitioned by 'year'
    CommonUtils.writeJson(memberMonthsPerMemberPerYearDF, args(3), None,true,1)

    // Stop the Spark session
    spark.stop()
  }
}
