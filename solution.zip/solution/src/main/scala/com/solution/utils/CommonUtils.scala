package com.solution.utils

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * A utility object for common Spark operations.
 */
object CommonUtils {

  /**
   * Creates and returns a SparkSession with the specified application name.
   *
   * @param appName The name of the Spark application.
   * @return A SparkSession instance.
   */
  def createSparkSession(appName: String): SparkSession = {
    SparkSession.builder()
      .appName(appName)
//      .master("local[*]")
//      .config("spark.ui.port", "4041") // Use a different port if the default 4040 is in use
//      .config("spark.driver.bindAddress", "127.0.0.1")
      .getOrCreate()
  }

  /**
   * Reads a CSV file from the specified path into a DataFrame.
   *
   * @param spark The SparkSession to use for reading the CSV.
   * @param path The path to the CSV file.
   * @param hasHeader Boolean indicating if the CSV file has a header row.
   * @param inferSchema Boolean indicating if the CSV files schema need to be infered.
   * @return A DataFrame representing the CSV data.
   */
  def readCsv(spark: SparkSession, path: String, hasHeader: Boolean = true, inferSchema: Boolean = true): DataFrame = {
    spark.read.option("header", hasHeader.toString).option("inferSchema", inferSchema).csv(path)
  }

  /**
   * Writes a DataFrame to a JSON file, with optional partitioning and coalescing.
   *
   * @param df The DataFrame to write.
   * @param path The output path where the JSON files will be stored.
   * @param partitionBy Optional: Column name to partition the output files by. Default is an empty string, which means no partitioning.
   * @param coalesce Optional: A boolean flag to determine if the DataFrame should be coalesced. Default is false.
   * @param numPartitions Optional: The number of partitions to coalesce the DataFrame into if coalescing is true. Ignored if coalesce is false.
   */
  def writeJson(df: DataFrame, path: String, partitionBy: Option[String] = None, coalesce: Boolean = false, numPartitions: Int = 1): Unit = {
    var outputDF = df

    // Apply coalesce if needed, ensuring it makes sense
    if (coalesce && numPartitions > 0) {
      outputDF = df.coalesce(numPartitions)
    }

    // Handle partitioning based on the partitionBy option
    partitionBy match {
      case Some(column) if column.nonEmpty => outputDF.write.mode("overwrite").partitionBy(column).json(path)
      case _ => outputDF.write.mode("overwrite").json(path)
    }
  }


}